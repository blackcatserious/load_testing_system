# Load Testing System


Автоматизация нагрузочного тестирования с помощью K6, GitHub Actions и современной панели управления.

## Сценарии
- workflow запускает тесты на PR, по расписанию и вручную
- результаты тестирования архивируются и доступны как artifacts
- поддержка HTTP/2/3, mTLS, OTel, chaos, adaptive load shaping, fuzzing, edge-кейсы

## Быстрый старт

1. Добавьте secrets (`BASE_URL`, `CLIENT_ID`, `CLIENT_SECRET`) в Settings → Secrets → Actions
2. Запустите workflow вручную или через PR
3. Откройте панель управления для мониторинга и анализа метрик

## Advanced

- Front-synthetics: сценарии на Playwright/Lighthouse, Web Vitals
- WCAG AA, Lighthouse Accessibility/Best Practices ≥ 90
- Адаптивная верстка, mobile-first, фокус-стили, контрастность
- Интеграция с CI/CD, экспорт артефактов, автоматизация тестов
- Поддержка property-based/fuzzing тестов, edge-кейсов, ретраев

## Инструкции по запуску

- Запуск тестов: `make load` или через workflow
- Просмотр отчетов: вкладка Reports в панели
- Управление целями: вкладка Targets

## Безопасность

- Все секреты хранятся через GitHub Secrets
- mTLS, ротация сертификатов, защита данных

## Troubleshooting

- Проверяйте логи в панели (Logs)
- Используйте вкладку Reports для анализа ошибок
- Для front-synthetics используйте Lighthouse/Playwright

## Контакты

- Вопросы и предложения: через Issues или Devin.AI
