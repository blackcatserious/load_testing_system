# Целевые эндпоинты для нагрузочного тестирования


- `/api` — базовый запрос
- `/api/login` — авторизация
- `/api/data` — получение данных

## Advanced Targets & Integrations

- `/api/v1/leads` — генерация лидов, property-based/fuzzing
- `/api/v1/cases/{id}/removals` — удаление кейса, edge-кейсы, ретраи
- `/api/v1/cases/{id}/status` — статус кейса, нагрузка на чтение
- Внешние интеграции: мокирование, песочницы, тестовые API

## Критерии успеха

- SLO: p95/p99 latency, error-rate, success-rate
- Автоотчёты, экспорт метрик, Web Vitals

## Troubleshooting

- Анализ ошибок по отчетам и логам
- Проверка защиты (WAF, rate-limit, mTLS)

